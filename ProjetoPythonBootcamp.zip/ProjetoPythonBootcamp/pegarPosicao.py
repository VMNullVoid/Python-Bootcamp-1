#Código auxiliar para pegar posição da tela
#Rode no ícone de play no canto superior direito, dê out+tab e clique no ponto a ser capturado pelo código
import time
import pyautogui
time.sleep(5)
print(pyautogui.position())
pyautogui.scroll(200)
