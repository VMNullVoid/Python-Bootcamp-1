import csv
from faker import Faker
#instância da extensão Faker em ptbr
fake = Faker('pt_BR')
#nome do arquivo csv a ser gerado
nomeArquivo = 'dados.csv'
#Cabeçalho do arquivo csv, é uma lista com os campos a serem preenchidos, entitulados do seguinte modo:
cabecalho = ['nome', 'email', 'endereco', 'telefone']
#Codigo para criar e preencher o arquivo csv com registros fictícios
with open(nomeArquivo, mode='w', newline='', encoding='utf-8') as csvfile:
  escritor = csv.writer(csvfile)
  #Para chamar a escrita dos cabeçalhos:
  escritor.writerow(cabecalho)
  #Gerar N registros 
  for _ in range(100): #O range pode ser qualquer tamanho
    nome = fake.name()   #gera nome fictício com base na biblioteca faker
    dominiofake = ['@example.net', '@example.org', '@example.com']
    email = fake.email().replace('@example.net',"@gmail.com",).replace( '@example.org','@gmail.com').replace('@example.com','@gmail.com') 
    endereco = fake.address().replace('\n',', ')  #gera endereço fictício com base na biblioteca faker
    telefone = fake.phone_number()  #gera telefone fictício com base na biblioteca faker

    #Escrever os quatro campos no arquivo
    escritor.writerow([nome, email, endereco, telefone])
    print(f"arquivo{nomeArquivo} criado com sucesso!!")


