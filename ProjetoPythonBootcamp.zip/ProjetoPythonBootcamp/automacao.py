#primeiro passo: entrar no site
#http://www.sauer.pro.br/python/automacao/index.html
import pyautogui
import time

pyautogui.PAUSE = 0.3

#Passo 1: abrir navegador(chrome)
pyautogui.press('win')
pyautogui.write('chrome')
pyautogui.press("enter")

#Entrar no link
time.sleep(1)
pyautogui.write("http://www.sauer.pro.br/python/automacao/index.html")
pyautogui.press("enter")
time.sleep(2)
#Passo 2: fazer login
#select o campo de login
pyautogui.click(x=410, y=445)
pyautogui.write("admin")
pyautogui.press("tab")
pyautogui.write("admin")
pyautogui.press("tab")
pyautogui.press("enter")
#Passo 3: Importar a base de pessoas pra cadastrar
import pandas as pd
import csv
tabela = pd.read_csv('dados.csv')
#Passo 4: cadastrar um aluno
for linha in tabela.index:
    nome = tabela.loc[linha,'nome']
    email = tabela.loc[linha,'email']
    endereco = tabela.loc[linha,'endereco']
    telefone = tabela.loc[linha,'telefone']
    #print(f"nome: {nome} - Email: {email} - Endereco: {endereco} - Tel: {telefone}")
tamanho = int(len(tabela.index))
contador = 0
while contador < tamanho+1:
 #Clicar no campo de nome
 pyautogui.click(x=278, y=357)
 #Insere dado na parte do nome
 pyautogui.write(str(nome))
 pyautogui.press("tab")
 pyautogui.sleep(1)
 #Insere dado no email
 pyautogui.write(str(email))
 pyautogui.press("tab")
 pyautogui.sleep(1)
 #Insere dado na parte do nome
 pyautogui.write(str(endereco))
 pyautogui.press("tab")
 pyautogui.sleep(1)
 #Insere dado na parte do nome
 pyautogui.write(str(telefone))
 pyautogui.sleep(1)
 pyautogui.press("tab")
 #Clicar no campo Cadastrar
 pyautogui.click(x=278, y=682)
 contador+=1
 #TEM QUE CONSERTAR UM ERRO DE LOCALIZAÇÃO DO CLICK NO LOOP
    
